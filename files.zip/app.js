const API_URL = "http://localhost:8080/api";

const state = {
  profs: [],
  ues: [],
  cours: [],
  seminaires: []
};

// =========================================================================
// CHARGEMENT DES DONNÉES
// =========================================================================
async function loadDataFromJava() {
  try {
    const [resProfs, resUes, resCours, resSeminaires] = await Promise.all([
      fetch(`${API_URL}/profs`),
      fetch(`${API_URL}/ues`),
      fetch(`${API_URL}/cours`),
      fetch(`${API_URL}/seminaires`)
    ]);

    state.profs      = await resProfs.json();
    state.ues        = await resUes.json();
    state.cours      = await resCours.json();
    state.seminaires = await resSeminaires.json();

    renderProfsList();
    renderUesList();
    renderCoursList();
    renderSeminairesList();
    renderCalendar();
    populateSelects();
    updateCounts();
  } catch (err) {
    console.error("Erreur de synchronisation avec Java :", err);
    toast("Erreur : Impossible de se connecter au serveur Java ❌");
  }
}

document.addEventListener("DOMContentLoaded", () => {
  initCalendarHeaders();
  goToToday();
  loadDataFromJava();
});

// =========================================================================
// SAUVEGARDE — PROF
// =========================================================================
async function saveProf() {
  const nom    = document.getElementById('prof-nom').value.trim();
  const prenom = document.getElementById('prof-prenom').value.trim();
  const age    = parseInt(document.getElementById('prof-age').value);
  const genre  = document.getElementById('prof-genre').value;

  if (!nom || !prenom || isNaN(age)) {
    toast('Veuillez remplir tous les champs du professeur');
    return;
  }

  try {
    const response = await fetch(`${API_URL}/profs`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nom, prenom, age, genre })
    });

    if (response.ok) {
      toast('Professeur enregistré ✓');
      document.getElementById('prof-nom').value    = '';
      document.getElementById('prof-prenom').value = '';
      document.getElementById('prof-age').value    = '';
      closeModal();
      await loadDataFromJava();
    }
  } catch (err) {
    toast('Erreur de sauvegarde côté serveur ❌');
  }
}

// =========================================================================
// SAUVEGARDE — UE
// =========================================================================
async function saveUE() {
  const matiere = document.getElementById('ue-matiere').value.trim();
  const credit  = parseInt(document.getElementById('ue-credit').value);

  if (!matiere || isNaN(credit)) {
    toast("Veuillez remplir tous les champs de l'UE");
    return;
  }

  try {
    const response = await fetch(`${API_URL}/ues`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ matiere, credit })
    });

    if (response.ok) {
      toast('UE enregistrée ✓');
      document.getElementById('ue-matiere').value = '';
      document.getElementById('ue-credit').value  = '';
      closeModal();
      await loadDataFromJava();
    }
  } catch (err) {
    toast('Erreur de sauvegarde côté serveur ❌');
  }
}

// =========================================================================
// SAUVEGARDE — COURS
// =========================================================================
async function saveCours() {
  const debut     = document.getElementById('cours-debut').value;
  const fin       = document.getElementById('cours-fin').value;
  const ueMatiere = document.getElementById('cours-ue').value;
  const profNom   = document.getElementById('cours-prof').value;

  if (!debut || !fin || !ueMatiere || !profNom) {
    toast('Veuillez remplir tous les champs du cours');
    return;
  }

  const ueAssociee  = state.ues.find(u => u.matiere === ueMatiere);
  const profAssocie = state.profs.find(p => p.nom === profNom);

  try {
    const response = await fetch(`${API_URL}/cours`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ heureDebut: debut, heureFin: fin, ue: ueAssociee, prof: profAssocie })
    });

    if (response.ok) {
      toast('Cours ajouté ✓');
      closeModal();
      await loadDataFromJava();
    }
  } catch (err) {
    toast("Erreur lors de l'enregistrement du cours ❌");
  }
}

// =========================================================================
// SAUVEGARDE — SÉMINAIRE
// =========================================================================
async function saveSeminaire() {
  const debut    = document.getElementById('sem-debut').value;
  const fin      = document.getElementById('sem-fin').value;
  const respNom  = document.getElementById('sem-responsable').value;
  const titre    = document.getElementById('sem-titre').value.trim(); // FIX: titre envoyé

  if (!debut || !fin || !respNom || !titre) {
    toast('Veuillez remplir tous les champs du séminaire');
    return;
  }

  const responsableAssocie = state.profs.find(p => p.nom === respNom);

  try {
    const response = await fetch(`${API_URL}/seminaires`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ heureDebut: debut, heureFin: fin, responsable: responsableAssocie, titre }) // FIX: titre inclus
    });

    if (response.ok) {
      toast('Séminaire ajouté ✓');
      closeModal();
      await loadDataFromJava();
    }
  } catch (err) {
    toast("Erreur lors de l'enregistrement du séminaire ❌");
  }
}

// =========================================================================
// SAUVEGARDE — depuis modal "Nouvel Événement" (onglets cours/séminaire)
// =========================================================================
async function saveEvent() {
  if (currentEventType === 'cours') {
    // Copier les valeurs vers les champs dédiés puis appeler saveCours
    document.getElementById('cours-debut').value = document.getElementById('ev-cours-debut').value;
    document.getElementById('cours-fin').value   = document.getElementById('ev-cours-fin').value;
    document.getElementById('cours-ue').value    = document.getElementById('ev-cours-ue').value;
    document.getElementById('cours-prof').value  = document.getElementById('ev-cours-prof').value;
    await saveCours();
  } else {
    document.getElementById('sem-debut').value        = document.getElementById('ev-sem-debut').value;
    document.getElementById('sem-fin').value          = document.getElementById('ev-sem-fin').value;
    document.getElementById('sem-responsable').value  = document.getElementById('ev-sem-responsable').value;
    document.getElementById('sem-titre').value        = document.getElementById('ev-sem-titre').value;
    await saveSeminaire();
  }
}

// =========================================================================
// SUPPRESSION
// =========================================================================
async function deleteCours(id) {
  try {
    const response = await fetch(`${API_URL}/cours/${id}`, { method: 'DELETE' });
    if (response.ok) {
      toast('Cours supprimé ✓');
      await loadDataFromJava();
    }
  } catch (err) {
    toast('Erreur lors de la suppression ❌');
  }
}

async function deleteSeminaire(id) {
  try {
    const response = await fetch(`${API_URL}/seminaires/${id}`, { method: 'DELETE' });
    if (response.ok) {
      toast('Séminaire supprimé ✓');
      await loadDataFromJava();
    }
  } catch (err) {
    toast('Erreur lors de la suppression ❌');
  }
}

async function deleteProf(id) {
  try {
    await fetch(`${API_URL}/profs/${id}`, { method: 'DELETE' });
    toast('Professeur supprimé ✓');
    await loadDataFromJava();
  } catch (err) {
    toast('Erreur lors de la suppression ❌');
  }
}

async function deleteUE(id) {
  try {
    await fetch(`${API_URL}/ues/${id}`, { method: 'DELETE' });
    toast('UE supprimée ✓');
    await loadDataFromJava();
  } catch (err) {
    toast('Erreur lors de la suppression ❌');
  }
}

// =========================================================================
// RENDU DES LISTES
// =========================================================================
function renderProfsList() {
  const el = document.getElementById('profs-list');
  if (!el) return;
  el.innerHTML = '';

  if (state.profs.length === 0) {
    el.innerHTML = '<p class="empty-state">Aucun professeur enregistré.</p>';
    return;
  }

  state.profs.forEach(p => {
    const card = document.createElement('div');
    card.className = 'item-card';

    const infoDiv = document.createElement('div');
    infoDiv.innerHTML = `
      <strong>${p.prenom} ${p.nom}</strong>
      <div style="font-size:0.75rem;color:var(--gray-500);margin-top:2px;">${p.age} ans • ${p.genre}</div>
    `;

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'delete-btn';
    deleteBtn.textContent = '×';
    deleteBtn.onclick = () => deleteProf(p.id); // FIX: utilise p.id fiable

    card.appendChild(infoDiv);
    card.appendChild(deleteBtn);
    el.appendChild(card);
  });
}

function renderUesList() {
  const el = document.getElementById('ues-list');
  if (!el) return;
  el.innerHTML = '';

  if (state.ues.length === 0) {
    el.innerHTML = '<p class="empty-state">Aucune UE enregistrée.</p>';
    return;
  }

  state.ues.forEach(u => {
    const card = document.createElement('div');
    card.className = 'item-card';

    const infoDiv = document.createElement('div');
    infoDiv.innerHTML = `
      <strong>${u.matiere}</strong>
      <div style="font-size:0.75rem;color:var(--gray-500);margin-top:2px;">${u.credit} crédits ECTS</div>
    `;

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'delete-btn';
    deleteBtn.textContent = '×';
    deleteBtn.onclick = () => deleteUE(u.id); // FIX: utilise u.id fiable

    card.appendChild(infoDiv);
    card.appendChild(deleteBtn);
    el.appendChild(card);
  });
}

function renderCoursList() {
  const el = document.getElementById('cours-list');
  if (!el) return;
  el.innerHTML = '';

  if (state.cours.length === 0) {
    el.innerHTML = '<p class="empty-state">Aucun cours planifié.</p>';
    return;
  }

  state.cours.forEach(c => {
    const d = new Date(c.heureDebut);
    const card = document.createElement('div');
    card.className = 'item-card event-cours-item';

    const infoDiv = document.createElement('div');
    infoDiv.innerHTML = `
      <strong>${c.ue?.matiere || 'Matière inconnue'}</strong>
      <div style="font-size:0.75rem;color:var(--gray-500);margin-top:2px;">Par: ${c.prof?.prenom || ''} ${c.prof?.nom || 'Inconnu'}</div>
      <div style="font-size:0.75rem;color:var(--sky-dark);font-weight:500;margin-top:2px;">
        Le ${d.toLocaleDateString()} à ${d.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
      </div>
    `;

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'delete-btn';
    deleteBtn.textContent = '×';
    deleteBtn.onclick = () => deleteCours(c.id); // FIX: utilise c.id fiable

    card.appendChild(infoDiv);
    card.appendChild(deleteBtn);
    el.appendChild(card);
  });
}

function renderSeminairesList() {
  const el = document.getElementById('seminaires-list');
  if (!el) return;
  el.innerHTML = '';

  if (state.seminaires.length === 0) {
    el.innerHTML = '<p class="empty-state">Aucun séminaire planifié.</p>';
    return;
  }

  state.seminaires.forEach(s => {
    const d = new Date(s.heureDebut);
    const card = document.createElement('div');
    card.className = 'item-card event-sem-item';

    const infoDiv = document.createElement('div');
    infoDiv.innerHTML = `
      <strong>${s.titre || 'Séminaire Académique'}</strong>
      <div style="font-size:0.75rem;color:var(--gray-500);margin-top:2px;">Responsable: ${s.responsable?.prenom || ''} ${s.responsable?.nom || 'Inconnu'}</div>
      <div style="font-size:0.75rem;color:var(--sky-dark);font-weight:500;margin-top:2px;">
        Le ${d.toLocaleDateString()} à ${d.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
      </div>
    `;

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'delete-btn';
    deleteBtn.textContent = '×';
    deleteBtn.onclick = () => deleteSeminaire(s.id); // FIX: utilise s.id fiable

    card.appendChild(infoDiv);
    card.appendChild(deleteBtn);
    el.appendChild(card);
  });
}

// =========================================================================
// CALENDRIER
// =========================================================================
let currentWeekStart = null;

const JOURS = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];

function getMonday(date) {
  const d = new Date(date);
  const day = d.getDay(); // 0=Dim, 1=Lun...
  const diff = (day === 0) ? -6 : 1 - day; // FIX: gestion du dimanche
  d.setDate(d.getDate() + diff);
  d.setHours(0, 0, 0, 0);
  return d;
}

function goToToday() {
  currentWeekStart = getMonday(new Date());
  renderCalendar();
}

function prevWeek() {
  currentWeekStart.setDate(currentWeekStart.getDate() - 7);
  renderCalendar();
}

function nextWeek() {
  currentWeekStart.setDate(currentWeekStart.getDate() + 7);
  renderCalendar();
}

function initCalendarHeaders() {
  const grid = document.getElementById('calendar-grid');
  if (!grid) return;

  // Cellule vide pour la colonne des heures
  const emptyHeader = document.createElement('div');
  emptyHeader.className = 'cal-time-header';
  grid.appendChild(emptyHeader);

  JOURS.forEach(jour => {
    const h = document.createElement('div');
    h.className = 'cal-day-header';
    h.dataset.jour = jour;
    h.textContent = jour;
    grid.appendChild(h);
  });

  // Lignes d'heures (8h–20h)
  for (let h = 8; h <= 20; h++) {
    const timeLabel = document.createElement('div');
    timeLabel.className = 'cal-time-label';
    timeLabel.textContent = `${h}:00`;
    grid.appendChild(timeLabel);

    JOURS.forEach(() => {
      const cell = document.createElement('div');
      cell.className = 'cal-cell';
      grid.appendChild(cell);
    });
  }
}

function renderCalendar() {
  if (!currentWeekStart) return;

  const grid = document.getElementById('calendar-grid');
  if (!grid) return;

  // Mise à jour des en-têtes avec les dates
  const weekEnd = new Date(currentWeekStart);
  weekEnd.setDate(weekEnd.getDate() + 5);
  const label = document.getElementById('week-label');
  if (label) {
    label.textContent = `Semaine du ${currentWeekStart.toLocaleDateString('fr-FR')} au ${weekEnd.toLocaleDateString('fr-FR')}`;
  }

  JOURS.forEach((jour, i) => {
    const dateOfDay = new Date(currentWeekStart);
    dateOfDay.setDate(dateOfDay.getDate() + i);
    const header = grid.querySelector(`[data-jour="${jour}"]`);
    if (header) {
      header.innerHTML = `<span class="day-name">${jour}</span><span class="day-date">${dateOfDay.getDate()}/${dateOfDay.getMonth() + 1}</span>`;
    }
  });

  // Nettoyer les anciens événements
  grid.querySelectorAll('.calendar-event').forEach(e => e.remove());

  // Affichage des Cours
  state.cours.forEach(c => {
    placeEventInCalendar(grid, {
      heureDebut: c.heureDebut,
      heureFin: c.heureFin,
      title: c.ue?.matiere || 'Cours',
      desc: `${c.prof?.prenom || ''} ${c.prof?.nom || ''}`,
      className: 'event-cours'
    });
  });

  // Affichage des Séminaires
  state.seminaires.forEach(s => {
    placeEventInCalendar(grid, {
      heureDebut: s.heureDebut,
      heureFin: s.heureFin,
      title: s.titre || 'Séminaire',
      desc: `Resp: ${s.responsable?.nom || 'Inconnu'}`,
      className: 'event-seminaire'
    });
  });
}

function placeEventInCalendar(grid, { heureDebut, heureFin, title, desc, className }) {
  const start = new Date(heureDebut);
  const end   = new Date(heureFin);

  // FIX: getDay() retourne 0 pour Dimanche → pas affiché (hors grille Lun-Sam)
  const dayOfWeek = start.getDay(); // 0=Dim, 1=Lun, ..., 6=Sam
  if (dayOfWeek === 0) return; // Dimanche ignoré proprement

  const colIndex = dayOfWeek; // Lundi=1 → colonne 1 (après la colonne heures)

  // Vérifier si l'événement est dans la semaine affichée
  const eventMonday = getMonday(start);
  if (eventMonday.getTime() !== currentWeekStart.getTime()) return;

  const startHour = start.getHours() + start.getMinutes() / 60;
  const endHour   = end.getHours()   + end.getMinutes()   / 60;

  // La grille CSS commence à la ligne 2 (ligne 1 = en-têtes)
  // Chaque demi-heure = 1 rangée, démarrant à 8h
  const rowStart = Math.round((startHour - 8) * 2) + 2;
  const rowEnd   = Math.round((endHour   - 8) * 2) + 2;

  if (rowStart < 2 || rowEnd <= rowStart) return; // hors plage 8h-20h

  const evEl = document.createElement('div');
  evEl.className = `calendar-event ${className}`;
  evEl.style.gridColumn = colIndex + 1; // +1 pour la colonne des heures
  evEl.style.gridRow    = `${rowStart} / ${rowEnd}`;

  evEl.innerHTML = `
    <div class="event-title">${title}</div>
    <div class="event-desc">${desc}</div>
    <div class="event-time">${start.getHours()}:${String(start.getMinutes()).padStart(2,'0')} - ${end.getHours()}:${String(end.getMinutes()).padStart(2,'0')}</div>
  `;

  grid.appendChild(evEl);
}

// =========================================================================
// SELECTS DES FORMULAIRES
// =========================================================================
function populateSelects() {
  const selectors = {
    'cours-ue':         { list: state.ues,   val: u => u.matiere, label: u => u.matiere },
    'cours-prof':       { list: state.profs, val: p => p.nom,     label: p => `${p.prenom} ${p.nom}` },
    'sem-responsable':  { list: state.profs, val: p => p.nom,     label: p => `${p.prenom} ${p.nom}` },
    'ev-cours-ue':      { list: state.ues,   val: u => u.matiere, label: u => u.matiere },
    'ev-cours-prof':    { list: state.profs, val: p => p.nom,     label: p => `${p.prenom} ${p.nom}` },
    'ev-sem-responsable':{ list: state.profs, val: p => p.nom,    label: p => `${p.prenom} ${p.nom}` },
  };

  for (const [id, cfg] of Object.entries(selectors)) {
    const sel = document.getElementById(id);
    if (!sel) continue;
    sel.innerHTML = '';
    cfg.list.forEach(item => {
      const opt = document.createElement('option');
      opt.value       = cfg.val(item);
      opt.textContent = cfg.label(item);
      sel.appendChild(opt);
    });
  }
}

// =========================================================================
// COMPTEURS
// =========================================================================
function updateCounts() {
  const map = {
    'profs-count':  `${state.profs.length} professeur(s) enregistré(s)`,
    'ues-count':    `${state.ues.length} UE enregistrée(s)`,
    'cours-count':  `${state.cours.length} cours enregistré(s)`,
    'sem-count':    `${state.seminaires.length} séminaire(s) enregistré(s)`,
  };
  for (const [id, text] of Object.entries(map)) {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
  }
}

// =========================================================================
// NAVIGATION VUES
// =========================================================================
function showView(viewName) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

  const view = document.getElementById(`view-${viewName}`);
  if (view) view.classList.add('active');

  const navItem = document.querySelector(`[data-view="${viewName}"]`);
  if (navItem) navItem.classList.add('active');
}

// =========================================================================
// MODALES
// =========================================================================
let currentEventType = 'cours';

function openModal(type) {
  // Cacher toutes les modales
  document.querySelectorAll('.modal').forEach(m => m.style.display = 'none');
  document.getElementById('modal-overlay').style.display = 'block';

  if (type === 'event') {
    document.getElementById('modal-event').style.display = 'block';
    selectEventType('cours', document.querySelector('#modal-event .tab-btn'));
  } else {
    const modal = document.getElementById(`modal-${type}`);
    if (modal) modal.style.display = 'block';
  }

  populateSelects();
}

function closeModal() {
  document.querySelectorAll('.modal').forEach(m => m.style.display = 'none');
  document.getElementById('modal-overlay').style.display = 'none';
}

function selectEventType(type, btn) {
  currentEventType = type;

  document.querySelectorAll('#modal-event .tab-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');

  document.getElementById('event-cours-form').style.display     = type === 'cours'     ? 'block' : 'none';
  document.getElementById('event-seminaire-form').style.display = type === 'seminaire' ? 'block' : 'none';
}

// =========================================================================
// TOAST
// =========================================================================
let toastTimer;
function toast(msg) {
  const el = document.getElementById('toast');
  if (!el) return;
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 3000);
}
